<?php
include "config.php";
session_start();
if(isset($_POST['submit'])){
    $occu = mysqli_real_escape_string($conn, $_POST['occu']);
    $duration = mysqli_real_escape_string($conn, $_POST['duration']);
    $salary = mysqli_real_escape_string($conn, $_POST['salary']);
    $job_desc = mysqli_real_escape_string($conn, $_POST['job_desc']);
  

    $select = mysqli_query($conn, "SELECT * FROM `jobs`") or 
    die('query failed');

    if(mysqli_num_rows($select) < 0){
        $message[] = '';
        echo "dsadsa";

    }else {
        mysqli_query($conn, "INSERT INTO `jobs`(occu, duration, salary, job_desc) 
        VALUES('$occu', '$duration', '$salary', '$job_desc')") or 
        die('query failed');
        $message[] = 'Registration Sucessfull!!';
        header('location: ../company-home.php');
        echo "sadar";


    }
}




?>