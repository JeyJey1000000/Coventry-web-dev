<?php
include "config.php";
session_start();
if(isset($_POST['submit'])){
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $telephone = mysqli_real_escape_string($conn, $_POST['telephone']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $edu = mysqli_real_escape_string($conn, $_POST['edu_background']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
    $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));

    $select = mysqli_query($conn, "SELECT * FROM `seeker` WHERE email = '$email' AND password = '$pass'") or 
    die('query failed');

    if(mysqli_num_rows($select) > 0){
        $message[] = '';

    }else {
        mysqli_query($conn, "INSERT INTO `seeker`(firstname, lastname, email, address, telephone, location, edu_background, password, cpassword) 
        VALUES('$firstname', '$lastname', '$email', '$address', '$telephone', '$location', '$edu', '$pass', '$cpass')") or 
        die('query failed');
        $message[] = 'Registration Sucessfull!!';
        header('location: ../seeker-login-page.php');



    }
}



?>