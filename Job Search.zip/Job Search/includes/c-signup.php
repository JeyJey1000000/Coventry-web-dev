<?php
include "config.php";
session_start();
if(isset($_POST['submit'])){
    $cname = mysqli_real_escape_string($conn, $_POST['cname']);
  
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $ctype = mysqli_real_escape_string($conn, $_POST['ctype']);
 
    $about = mysqli_real_escape_string($conn, $_POST['about']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));

    $select = mysqli_query($conn, "SELECT * FROM `company` WHERE email = '$email' AND password = '$pass'") or 
    die('query failed');

    if(mysqli_num_rows($select) > 0){
        $message[] = '';

    }else {
        mysqli_query($conn, "INSERT INTO `company`(cname, email, ctype, about, password) 
        VALUES('$cname', '$email', '$ctype', '$about', '$pass')") or 
        die('query failed');
        $message[] = 'Registration Sucessfull!!';
        header('location: ../company-login.php');



    }
}



?>