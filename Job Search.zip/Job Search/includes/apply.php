<?php
include "config.php";
if(isset($_POST['submit'])){

$applyid = $_POST['applyid'];
$job = $_POST['profession'];
$applying = $_POST['applying'];
$email = $_POST['email'];
$compid = $_POST['compid'];
$sql = "INSERT INTO `applicant`( jobid, job, applicant, applicant_email, comp_id) VALUES('$applyid', '$job', '$applying','$email','$compid')";
$result = mysqli_query($conn,$sql);
header('location: ../seeker-home.php');
}

?>